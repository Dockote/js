function amount(x, y) {
  return x + y;
}
// let amt = amount(x, y);

function difference(x, y) {
  return x - y;
}
// let diff = difference(x, y);

function multiplication(x, y) {
  return x * y;
}
// let mtp = multiplication(x, y);

function division(x, y) {
  return x / y;
}
// let dvs = division(x, y);
