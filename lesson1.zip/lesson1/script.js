// console.log('Hello World!');
// console.log(a);
// var a = 1;
// console.log(a);
// var a;
// console.log(a);
// a = 1;
// console.log(a);

// console.log(a);
// const a = 1;
// console.log(a);

// var a = 1;
// console.log(a);
// {
//     var a = 2;
//     console.log(a);
//     {
//         var a = 3;
//         console.log(a);
//     }
// }
// console.log(a);

// let a = 1;
// console.log(a);
// {
//     let a = 2;
//     console.log(a);
//     {
//         let a = 3;
//         console.log(a);
//     }
// }
// console.log(a);

// let userName = 'Vasya';
/*
some code
 */

// /**
//  * Функция сложения
//  * @param a{Number}
//  * @param b{Number}
//  * @returns {Number}
//  */
// function sum(a, b) {
//     return a + b;
// }
//
// sum(1, 5);

// String

// let a = 'Hello!';
// let a = "Hello!";
// let a = `Hello!`;

// let name = 'Vasya';

// console.log('Привет ' + name);
// console.log(`Привет ${name}`);

// console.log('first string\nsecond string');
// console.log(`first string
// second string`);
// console.log('first string \
// second string');

// console.log('Он сказал - "Привет!".');
// console.log('Он сказал - \'Привет!\'.');
// console.log("Он сказал - 'Привет!'.");
// console.log("Он сказал - \"Привет!\".");

// let a = 1;
// let a = 3.14;
// let a = 10 / 0;

// let a = 10 * 'Hi!';
// let a = 10 * '3.14';
// console.log(a, typeof a);

// let a = '3.14';
// console.log(a, typeof a);
// a = +a;
// // a = Number(a);
// console.log(a, typeof a);

// let a = 3.14;
// console.log(a, typeof a);
// a = a + '';
// a = Number(a);
// console.log(a, typeof a);

// let a = '10';
//
// console.log(-a);

// let a = '3.14';

// console.log(parseInt(a));
// console.log(parseFloat(a));

// console.log(0xf);
// console.log(2e3);
// let a = 1_000_000;
// console.log(a);

// boolean (true / false)
// null
// undefined
// symbol
// 'use strict';
// a = 10;
// // window.a = 10;
//
// console.log(a);

// Арифметические
// console.log(6 + 4);
// console.log(6 - 4);
// console.log(6 * 4);
// console.log(6 / 4);
// console.log(6 ** 4);
// console.log(6 % 4);

// let a = 1;
// a += 2; // a = a + 2;
//
// console.log(a);

// console.log('string1' + 'string2');
// console.log('1' + '1'); // 11
// console.log('1' + 1); // 11
// console.log(1 + '1'); // 11
// console.log(1 + +'1'); // 2
// console.log(1 + 1); // 2

// Сравнение
// const a = 5; b = 5;
// a > b;
// a >= b;
// a < b;
// a <= b;
// a == b;
// a === b;
// a != b;
// a !== b;

// const userAnswer = +prompt('Введите температуру: ');
// console.log(userAnswer);
// alert(userAnswer);
